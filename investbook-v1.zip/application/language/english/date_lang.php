<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['date_year'] = ' year';
$lang['date_years'] = ' years';
$lang['date_month'] = ' month';
$lang['date_months'] = ' months';
$lang['date_week'] = ' week';
$lang['date_weeks'] = ' weeks';
$lang['date_day'] = 'd';
$lang['date_days'] = 'd';
$lang['date_hour'] = 'h';
$lang['date_hours'] = 'h';
$lang['date_minute'] = 'm';
$lang['date_minutes'] = 'm';
$lang['date_second'] = 's';
$lang['date_seconds'] = 's';
